CPSC 335-05 Project 1 Cella Ant 12

Class Number: 335-05
Project Number: 1
Project Name: Cella Ant 12
Team Name: WOC
Team Members: Will Covington, Caesar Mier

CONTENTS:
-CellaAnt12.html
-draw-stuff.js
-styles.css
-README.txt

EXTERNAL REQUIREMENTS:
-None

SETUP AND INSTALLATION:
1. Unpack Zip folder.

SAMPLE INVOCATION:
1. Navigate into the folder named "code".
2. Drag the file CellaAnt12.html into a Google Chrome window to open project.
3. Project will automatically begin execution upon opening.

FEATURES:
-The algorithm will automatically begin when the page is opened. 
-It will run through 1,000 iterations before stopping. 
-The number of moves can be adjusted in the file CellaAnt12.html by setting the value of the variable named 	"moves".

BUGS:
-None

