# CPSC-362-Project
Covid-19 Web Application
# Master Folder
  - inde.html: main html file that contains various links and tags to host the site.
  - mian.css: contains styling for the html file well as gid layouts.
  - main.js: provides functionality for the site and requests information for an api.
  - covid-19.jpg: background image for nidex.html page.
# API
  - source: https://rapidapi.com/Gramzivi/api/covid-19-data/endpoints
# Demo
  - site: https://itsjuanito.github.io/CPSC-362-Project/
