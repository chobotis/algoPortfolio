Team 12 Members

Rosa Cho
Thomas Fang
Louis Zuckerman
Tristan Stewart
