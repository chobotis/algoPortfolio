**Thank you for your contribution to building the website**

*What's the purpose of the pull request?*
 - [ ] This pull request adds a new feature to the website
 - [ ] It removes a bug
 - [ ] Other
 
 If other, could you specify?
 
 Before submitting the pull request, please make sure:
  - [ ] Your code builds clean without any errors or warnings
