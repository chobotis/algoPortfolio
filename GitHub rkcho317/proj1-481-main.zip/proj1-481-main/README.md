#proj1-381
Group 12: 

Rosa Cho
Thomas Fang
Tristan Stewart
Louis Zuckerman